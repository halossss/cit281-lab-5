const fastify = require("fastify")({
    logger: false,
})

const students = [
    {
      id: 1,
      last: "Last1",
      first: "First1",
    },
    {
      id: 2,
      last: "Last2",
      first: "First2",
    },
    {
      id: 3,
      last: "Last3",
      first: "First3",
    }
  ];

  function findStudentByID(id) {
    // Will return the first student object from array found with the matching ID
    return students.find(s => s.id === id);
  }

fastify.get("/cit/student", (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(students);
});

fastify.get("/cit/student/:id", (request, reply) => {
    console.log("ID:", request.params.id);
    const {id = ''} = request.params;
    if (id.length > 0) {
        let student = findStudentByID(parseInt(id));
        if (student !== undefined) {
            reply
                .code(200)
                .header("Content-Type", "application/json; charset=utf-8")
                .send(student);
        } else {
            reply
                .code(404)
                .header("Content-Type", "application/json; charset=utf-8")
                .send({error: 'Student ID not found'});
        }
    } else {
        reply
            .code(404)
            .header("Content-Type", "application/json; charset=utf-8")
            .send({error: 'No student ID provided'});
    }
});

fastify.get("*", (request, reply) => {
    reply
        .code(404)
        .header("Content-Type", "text/html; charset=utf-8")
        .send("<h1>error 404, route not found</h1>");
});

fastify.post("/cit/student/name", (request, reply) => {
    const { first = "", last = "" } = request.body;
    if (first && last) {
        const newId = students.length + 1;
        const newStudent = {
            id: newId,
            first: first,
            last: last
        };
        students.push(newStudent);
        reply
            .code(201)
            .header("Content-Type", "application/json; charset=utf-8")
            .send(newStudent);
    } else {
        reply
            .code(400)
            .header("Content-Type", "application/json; charset=utf-8")
            .send({ error: 'Both first and last names are required' });
    }
});


const listenIP = "localhost";
const listenPort = 8082;
fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log(`Server listening on ${address}`);
});
